
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.cors_adminer_bundle = "/bundles/corsadminer/studio/514d43959786aa509779050ce4198dbc/static/js/remoteEntry.js"

      
    