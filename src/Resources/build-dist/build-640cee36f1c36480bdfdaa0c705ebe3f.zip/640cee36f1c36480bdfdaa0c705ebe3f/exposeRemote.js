
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.cors_adminer_bundle = "/bundles/corsadminer/studio/640cee36f1c36480bdfdaa0c705ebe3f/static/js/remoteEntry.js"

      
    