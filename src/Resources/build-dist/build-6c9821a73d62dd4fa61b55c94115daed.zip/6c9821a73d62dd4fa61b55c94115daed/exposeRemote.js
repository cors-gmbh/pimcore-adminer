
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.cors_adminer_bundle = "/bundles/corsadminer/studio/6c9821a73d62dd4fa61b55c94115daed/static/js/remoteEntry.js"

      
    