
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.cors_adminer_bundle = "/bundles/corsadminer/studio/14443883fff1c0b316157b6b198dc547/static/js/remoteEntry.js"

      
    